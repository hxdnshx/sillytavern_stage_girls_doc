function showMessage(): void {
  alert("你点击了按钮！");
}
