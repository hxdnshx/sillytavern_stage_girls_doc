declare const toml: any; //避免ts报错
  
const tomlStr = `
   title = "TOML Example"
   [owner]
   name = "John Doe"
   `;
export function tomlFn(): any{
    return toml.parse(tomlStr);//使用toml库
}

export function detectMessageUpdated(message_id: number) {
  alert(`你刚刚修改了第 ${message_id} 条聊天消息对吧😡`);
}